# Areas

One note per ongoing part of your life, for example `Classes.md`, `Job.md`, `Club.md`. Two lines each is enough to start.
