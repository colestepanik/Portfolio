# Tool Roles

What each app is for.

- Obsidian: my vault, the source of truth.
- Claude or ChatGPT: reads the vault, helps, writes back.
- Google Drive: syncs the vault so my phone can reach it.
