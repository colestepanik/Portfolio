# Identity

Who my AI is to me and how it should talk to me. Paste the version from the interview here.
