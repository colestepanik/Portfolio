# Operating Manual

Paste the Operating Manual your AI wrote after the interview here.

## Priorities, ranked
1.
2.
3.

## How I decide when things collide

## Rules I always follow

## How I want help
