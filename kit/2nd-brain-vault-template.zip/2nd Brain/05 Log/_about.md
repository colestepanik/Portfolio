# Log

Your AI writes one file per day here, named `YYYY-MM-DD.md`, with short past-tense lines and an `## Open` section at the bottom.
