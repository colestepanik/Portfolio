# Projects

One note per project with an end date: goal, deadline, next step.
