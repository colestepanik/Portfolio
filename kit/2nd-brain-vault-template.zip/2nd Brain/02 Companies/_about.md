# Companies

One note per organization, team, or employer, with the same two sections as People.
