# Welcome to your 2nd Brain

This folder is your vault. Every note is a plain text file you own.

- `00 Core`: who you are and how you decide. Your AI reads these every chat.
- `01 Areas`: one note per big part of your life (a class, a job, a club).
- `02 People` and `02 Companies`: one note per person or organization.
- `03 Projects`: things with an end date.
- `05 Log`: one note per day, written by your AI.
- `06 Archive`: finished work.
- `_interview`: raw interview transcripts.
