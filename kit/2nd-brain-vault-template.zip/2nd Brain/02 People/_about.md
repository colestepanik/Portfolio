# People

One note per person, named `First Last.md`.

Template:

```
## On file
- How we met:
- What they do:

## My read
(pending)
```
